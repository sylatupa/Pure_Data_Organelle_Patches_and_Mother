!!!Do not Delete this, used for sample tracking!!!

Put samples in this folder, or record and save them with Deterior :)

Deterior calls its samples loop-#.wav

Deterior starts counting from the highest loop-# number.

When Patch is running and you manually add samples to the Sounds folder make sure to reload the patch
so you don't overwrite the samples you put in and confuse Deterior.
